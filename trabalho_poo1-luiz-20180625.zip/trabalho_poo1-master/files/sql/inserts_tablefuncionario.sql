INSERT INTO Funcionario(FK_Cadastro_id, senha, ativo) VALUES
(1,'admin123',1),
(5,'sys123',1),
(7,'litesql',1),
(17,'OhMich8rahl',1),
(22,'faex4naing',1),
(25,'eid3adoh0qu',1),
(32,'ohy9ahdaid',1),
(33,'ieng9Wab1jai',1),
(44,'xa5eiphea9ei',1),
(50,'mahS8juuxae',1)