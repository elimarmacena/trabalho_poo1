package sistema;
import java.util.ArrayList;



public class teste {
    public static void main (String[] args){
		Funcionario fun = new Funcionario();
		fun.cadastroAcidente();

    }
}
