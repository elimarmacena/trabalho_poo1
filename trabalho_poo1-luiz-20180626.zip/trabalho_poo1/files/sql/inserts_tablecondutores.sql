INSERT INTO condutor (FK_Cadastro_id,FK_cnh_id) VALUES
(21,1),
(29,2),
(46,3),
(23,4),
(25,5),
(40,6),
(26,7),
(49,8),
(35,9),
(42,10)