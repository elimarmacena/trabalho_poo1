INSERT INTO Ocorrencia_acidente (condutor_titular,velocidade, FK_Acidente_id, FK_Veiculo_id, FK_Condutor_id) VALUES
(0,80,2,1,1),
(1,90,3,2,2),
(0,70,1,4,4),
(0,80,1,3,3),
(1,100,4,5,5),
(0,80,5,6,6),
(1,89,6,7,7),
(0,79,7,8,8),
(0,76,8,9,9),
(1,91,9,10,10),
(1,100,10,3,3)